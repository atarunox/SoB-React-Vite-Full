// src/utils/locationHandlers/gamblingHallServices.js
// Executors for Gambling Hall services (Entertainment + Cashier + Specials)
// Keep prompts for dice/choices; no autoroll unless user leaves blank.

import { loadTownState, saveTownState } from '../../utils/townState';

// ----- small dice helpers (prompt-first, with safe fallbacks) -----
const D6 = () => Math.floor(Math.random() * 6) + 1;
const rollND = (n, s = 6) => Array.from({ length: n }, () => Math.floor(Math.random() * s) + 1);

// ----- context helpers (mirror Saloon style) -----
const getActiveHero = (ctx) => {
  const id = ctx.getActiveHeroId?.();
  return id ? (ctx.getHeroById?.(id) || ctx.getHero?.(id) || { id }) : null;
};

function effectiveStat(ctx, hero, stat) {
  if (ctx.getEffectiveStat) return ctx.getEffectiveStat(hero.id, stat);
  if (ctx.calculateStatFor) return ctx.calculateStatFor(hero.id, stat);
  return (
    hero?.[stat] ??
    hero?.[stat?.toLowerCase?.()] ??
    hero?.core?.[stat] ??
    hero?.stats?.[stat] ??
    3
  );
}

const canAfford = (hero, costGold = 0, costDS = 0) =>
  (hero?.gold || 0) >= costGold && (hero?.darkStone || 0) >= costDS;

const pay = (ctx, heroId, { gold = 0, darkStone = 0 } = {}) => {
  ctx.updateHero?.(heroId, (h) => ({
    ...h,
    gold: Math.max(0, (h.gold || 0) - gold),
    darkStone: Math.max(0, (h.darkStone || 0) - darkStone),
  }));
};

const addGold = (ctx, heroId, amt = 0) => {
  if (!amt) return;
  ctx.updateHero?.(heroId, (h) => ({ ...h, gold: (h.gold || 0) + amt }));
};

const addXP = (ctx, heroId, amt = 0) => {
  if (!amt) return;
  ctx.updateHero?.(heroId, (h) => ({ ...h, xp: (h.xp || 0) + amt }));
};

// Flag used by GH event 12: first Poker win may award a World/Artifact bonus
function isFirstPokerWinAwardsArtifact() {
  const s = loadTownState() || {};
  return !!s?.gamblingHallFlags?.firstPokerWinAwardsArtifact; // set by handler file already present
}

// Convenience: add Unwanted Attention marker if your engine supports it
const addUA = (ctx, heroId, n = 1) => ctx.addCondition?.(heroId, { type: 'UnwantedAttention', delta: +n });

// ----- main executor ---------------------------------------------------------
/**
 * performGamblingHallService(serviceId, params?, ctx?)
 * Returns: { log: string[], actions?: any[], ui?: any }
 *
 * Known service IDs (aligned to data/tabs):
 *  - gh_five_card_draw_poker
 *  - gh_brimstone_craps
 *  - gh_devils_wheel
 *  - gh_cash_in_dark_stone
 *  - gh_rob_cashier
 *  - gh_the_devils_own
 *  - gh_dark_stone_poker_chip
 */
export async function performGamblingHallService(serviceId, params = {}, ctx = {}) {
  const hero = getActiveHero(ctx);
  if (!hero?.id) return { log: ['[GamblingHall] No active hero.'] };

  const log = [];
  const toast = (m) => ctx.toast?.(m);

  // ---------------- Entertainment ----------------

  {
    id: 'gh_five_card_draw_poker',
    kind: 'Service',
    name: 'Five Card Draw Poker',
    price: 50,
    tags: ['Gambling', 'Limit:ThreePerVisit', 'Entertainment'],
    rules: {
      text: [
        'Roll 5 dice to represent your “hand”.',
        'You may then pay $50–$250 more as an Extra Bet (prompt).',
        'Make a Cunning test based on your hand (pairs/straights/etc.) — see rulebook hand chart.',
        'If any dice are re-rolled during the Cunning test, immediately gain an Unwanted Attention marker.',
        'If successful, gain D6×$25 as well as double your Extra Bet.',
        'If failed, you lose the Poker game and your bet.',
        'If this is your first win this visit and the event (12) is active, draw a World card then an Artifact from that World.',
      ],
      ui: { promptDice: true, promptExtraBet: true },
      limitPerVisit: 3,
    },
  },
  {
    id: 'gh_brimstone_craps',
    kind: 'Service',
    name: 'Brimstone Craps',
    price: 100,
    tags: ['Gambling', 'Limit:OncePerVisit', 'Entertainment'],
    rules: {
      text: [
        'Make a Luck 5+ test.',
        'If successful, gain $100 for every 5+ rolled.',
        'If failed, you leave with nothing to show for it.',
      ],
      test: { stat: 'Luck', target: 5, prompt: true },
      limitPerVisit: 1,
    },
  },
  {
    id: 'gh_devils_wheel',
    kind: 'Service',
    name: "The Devil's Wheel",
    price: 25,
    tags: ['Gambling', 'Limit:ThreePerVisit', 'Entertainment'],
    rules: {
      text: [
        'Play the mini-game as in rulebook. Prompt for point totals and award per chart.',
        'On jackpot/Artifact collection, also pay D6×$25 to each other Hero currently at the Gambling Hall.',
      ],
      ui: { promptDice: true, promptPoints: true },
      limitPerVisit: 3,
    },
  },

  // ---------------- Cashier & “Purchases” ----------------
  {
    id: 'gh_cash_in_dark_stone',
    kind: 'Service',
    name: 'Cash in Dark Stone',
    price: 0,
    tags: ['Cashier'],
    rules: {
      text: [
        'Sell Dark Stone shards to the cashier for $50 each.',
        'Prompt for how many shards to sell.',
      ],
      ui: { requiresNumberInput: 'darkStoneToSell' },
    },
  },
  {
    id: 'gh_rob_cashier',
    kind: 'Service',
    name: 'Rob the Gambling Hall Cashier',
    price: 0,
    tags: ['OutlawOnly', 'Limit:OncePerTownStay'],
    rules: {
      text: [
        'Make a Cunning 6+ test.',
        'If successful, each 6 rolled gains D6×$100 AND an Unwanted Attention marker.',
        'For each 1 rolled, take D6 Hits during the shootout that ensues.',
        'If failed, you are arrested at dawn — Lore 4+ test to escape the jail and flee Town (ending your Visit). Gain 20 XP, become Wanted!',
      ],
      test: { stat: 'Cunning', target: 6, prompt: true },
      followups: ['Lore 4+ escape on fail'],
      limitPerTownStay: 1,
    },
  },

  // ---------------- Special Purchases (Charms/Gear sold here) ----------------
  {
    id: 'gh_the_devils_own',
    kind: 'Service',
    name: "The Devil's Own",
    price: 600,
    tags: ['Charm', 'NoHolyOrTribal'],
    rules: {
      text: [
        'Buy a hellish charm. Once per Adventure/Town Stay, take D3 Corruption Hits, then test Willpower to Recover the same amount of Grit.',
      ],
      ui: { promptDice: true },
    },
  },
  {
    id: 'gh_dark_stone_poker_chip',
    kind: 'Service',
    name: 'Dark Stone Poker Chip',
    price: { gold: 800, darkStone: 1 },
    tags: ['DarkStone', 'Charm'],
    rules: {
      text: ['+1 Luck. Any time you gain Gold while Gambling, you gain an extra $50. Limit one.'],
    },
  },
];

export default gamblingHallServices;

// -------------------- EXECUTOR (new) --------------------
const D6 = () => Math.floor(Math.random() * 6) + 1;

const getActiveHero = (ctx) => {
  const id = ctx.getActiveHeroId?.();
  return id ? (ctx.getHeroById?.(id) || ctx.getHero?.(id) || { id }) : null;
};

const canAffordGold = (hero, amt) => (hero?.gold || 0) >= (amt || 0);

const payGold = (ctx, id, amt) =>
  amt ? ctx.updateHero?.(id, (h) => ({ ...h, gold: Math.max(0, (h.gold || 0) - amt) })) : undefined;

const addGold = (ctx, id, amt) =>
  amt ? ctx.updateHero?.(id, (h) => ({ ...h, gold: (h.gold || 0) + amt })) : undefined;

const addXP = (ctx, id, amt) =>
  amt ? ctx.updateHero?.(id, (h) => ({ ...h, xp: (h.xp || 0) + amt })) : undefined;

function applyGamblingMultiplier(amount) {
  // Saloon Event (12) doubles gambling winnings this visit
  const s = loadTownState() || {};
  const dbl = s?.saloonVisitFlags?.doubleGambling ? 2 : 1; // set by Saloon handler display/apply
  return amount * dbl;
}

/**
 * Minimal, prompt-first executor. We lean on the UI prompts instead of auto-rolling.
 */
export async function performGamblingHallService(serviceId, params = {}, ctx = {}) {
  const hero = getActiveHero(ctx);
  if (!hero?.id) return { log: ['[GamblingHall] No active hero.'] };

  const id = hero.id;
  const log = [];
  const toast = (m) => ctx.toast?.(m);

  // ---------- Five Card Draw Poker ----------
  if (serviceId === 'gh_five_card_draw_poker') {
    const base = 50;
    if (!canAffordGold(hero, base)) {
      toast?.('Not enough gold.');
      return { log: ['Insufficient gold.'] };
    }
    payGold(ctx, id, base);
    log.push(`Paid $${base}.`);

    // Extra bet prompt (UI constrains to 0–250 ideally)
    let extra = 0;
    if (ctx.promptNumber) {
      const e = await ctx.promptNumber('Extra Bet ($0–$250)?', 'extra');
      extra = Math.max(0, Math.min(250, Number(e || 0)));
    }
    if (extra) {
      if (!canAffordGold(hero, extra)) {
        toast?.('Not enough gold for Extra Bet.');
        return { log: ['Insufficient gold for Extra Bet.'] };
      }
      payGold(ctx, id, extra);
      log.push(`Extra Bet: $${extra}.`);
    }

    // Resolve success: prompt-first (table adjudicates the actual “hand”)
    let success = false;
    if (ctx.promptYesNo) {
      success = !!(await ctx.promptYesNo({ message: 'Did you pass the Poker Cunning test?', defaultValue: false }));
    } else if (ctx.doSkillCheck) {
      // fallback generic Cunning 5+ if UI lacks custom poker adjudication
      success = !!(await ctx.doSkillCheck(id, { stat: 'Cunning', target: 5, prompt: true }));
    }

    if (!success) {
      toast?.('You lose the hand.');
      log.push('Poker: failed the test.');
      return { log };
    }
// HIGH STAKES bonus check
const s = loadTownState() || {};
const flags = s.gamblingHallFlags || {};

if (!flags.usedHighStakes && flags.highStakesActive) {
    await performGamblingHallHighStakes(ctx);
    flags.usedHighStakes = true;
    s.gamblingHallFlags = flags;
    saveTownState(s);
}
,
    // Winnings: D6×$25 + 2×Extra Bet, doubled if Saloon(12) flag is active
    const d = (await ctx.promptNumber?.('Poker payout roll (D6)', 'die')) ?? D6();
    let payout = d * 25 + (extra ? extra * 2 : 0);
    payout = applyGamblingMultiplier(payout);
    addGold(ctx, id, payout);
    toast?.(`Poker win: +$${payout}.`);
    log.push(`Poker payout: D6(${d})×25 + 2×$${extra} => $${payout}.`);

    // First Poker Win this visit may award Artifact if Gambling Hall event (12) is up
    const s = loadTownState() || {};
    if (s.gamblingHallFlags?.firstPokerWinAwardsArtifact && ctx.drawWorldThenArtifact) {
      await ctx.drawWorldThenArtifact(id);
      toast?.('Bonus: Draw a World, then an Artifact (event bonus).');
      log.push('Awarded bonus World+Artifact (event 12).');
      // clear flag if you want it once-per-visit:
      saveTownState({
        ...s,
        gamblingHallFlags: { ...(s.gamblingHallFlags || {}), firstPokerWinAwardsArtifact: false },
      });
    }

    return { log };
  }

  // ---------- Brimstone Craps ----------
  if (serviceId === 'gh_brimstone_craps') {
    const cost = 100;
    if (!canAffordGold(hero, cost)) {
      toast?.('Not enough gold.');
      return { log: ['Insufficient gold.'] };
    }
    payGold(ctx, id, cost);
    log.push(`Paid $${cost}.`);

    // Prompt the table to declare number of 5+ successes (Luck test is per-die ≥ 5)
    let successes = 0;
    if (ctx.promptNumber) {
      const n = await ctx.promptNumber('How many 5+ successes did you roll on your Luck test?', 'succ');
      successes = Math.max(0, Number(n || 0));
    } else {
      // fallback: generic Luck 5+ single die
      const ok = await ctx.doSkillCheck?.(id, { stat: 'Luck', target: 5, prompt: true });
      successes = ok ? 1 : 0;
    }

    let payout = successes * 100;
    payout = applyGamblingMultiplier(payout);
    if (payout > 0) {
      addGold(ctx, id, payout);
      toast?.(`Craps: +$${payout}.`);
      log.push(`Craps: successes ${successes}, payout $${payout}.`);
    } else {
      toast?.('Craps: no winnings.');
      log.push('Craps: no payout.');
    }
    return { log };
  }

  // ---------- Devil's Wheel ----------
  if (serviceId === 'gh_devils_wheel') {
    const cost = 25;
    if (!canAffordGold(hero, cost)) {
      toast?.('Not enough gold.');
      return { log: ['Insufficient gold.'] };
    }
    payGold(ctx, id, cost);
    log.push(`Paid $${cost}.`);

    // Let UI drive minigame; we just support two prompts for outcome
    const jackpot = !!(await ctx.promptYesNo?.({ message: 'Did the table hit a jackpot?', defaultValue: false }));
    if (jackpot) {
      // Pay D6×$25 to each other Hero here
      const here = ctx.getHeroesAtShop?.('gamblingHall') || [id];
      const others = here.filter((hid) => hid !== id);
      const d = (await ctx.promptNumber?.('Jackpot payout roll to others (D6)', 'die')) ?? D6();
      const gift = d * 25;
      for (const hid of others) addGold(ctx, hid, gift);
      toast?.(`Jackpot: each other Hero here gains $${gift}.`);
      log.push(`Jackpot gift to ${others.length} others: $${gift} each.`);
    }

    // Optional: points/result for personal payout—defer to UI
    return { log };
  }

  // ---------- Cash in Dark Stone ----------
  if (serviceId === 'gh_cash_in_dark_stone') {
    const max = Number(hero.darkStone || 0);
    if (max <= 0) {
      toast?.('You have no Dark Stone shards.');
      return { log: ['No Dark Stone to sell.'] };
    }
    const n = await ctx.promptNumber?.(`How many Dark Stone shards to sell? (0–${max})`, 'count');
    const count = Math.max(0, Math.min(max, Number(n || 0)));
    if (count <= 0) return { log: ['No shards sold.'] };

    const gold = count * 50;
    addGold(ctx, id, gold);
    ctx.updateHero?.(id, (h) => ({ ...h, darkStone: Math.max(0, (h.darkStone || 0) - count) }));
    toast?.(`Sold ${count} shard(s) for $${gold}.`);
    log.push(`Sold ${count}× Dark Stone → $${gold}.`);
    return { log };
  }

  // ---------- Rob the Cashier ----------
  if (serviceId === 'gh_rob_cashier') {
    // We delegate dice to UI: ask how many sixes / ones were rolled on the Cunning test
    const passed = !!(await ctx.promptYesNo?.({ message: 'Did you pass the Cunning 6+ test?', defaultValue: false }));
    if (!passed) {
      // Arrested at dawn — Lore 4+ to escape and flee Town (end visit), +20 XP, become Wanted
      const escaped = !!(await ctx.doSkillCheck?.(id, { stat: 'Lore', target: 4, prompt: true }));
      addXP(ctx, id, 20);
      ctx.updateHero?.(id, (h) => ({ ...h, isDone: true, wanted: true, jailed: !escaped }));
      toast?.(escaped ? 'You slip out of jail and flee town.' : 'You are jailed!');
      return { log: [escaped ? 'Escaped and fled Town.' : 'Jailed. +20 XP, Wanted.'] };
    }

    const sixes = Number((await ctx.promptNumber?.('How many 6s did you roll?', 'sixes')) || 0);
    const ones = Number((await ctx.promptNumber?.('How many 1s did you roll?', 'ones')) || 0);

    // Each 6 → D6×$100 and an Unwanted Attention marker
    for (let i = 0; i < sixes; i++) {
      const d = (await ctx.promptNumber?.('Payout roll (D6) for each 6', 'die')) ?? D6();
      addGold(ctx, id, d * 100);
      ctx.addCondition?.(id, { type: 'UnwantedAttention', delta: +1 });
    }

    // Each 1 → D6 Hits
    for (let i = 0; i < ones; i++) {
      const hits = (await ctx.promptNumber?.('Shootout Hits (D6) for each 1', 'die')) ?? D6();
      ctx.updateHero?.(id, (h) => ({ ...h, wounds: (h.wounds || 0) + hits }));
    }

    toast?.('Robbery resolved.');
    log.push(`Robbery: ${sixes}× (D6×$100 & UA), ${ones}× (D6 Hits).`);
    return { log };
  }

  // ---------- Purchases: Charms ----------
  if (serviceId === 'gh_the_devils_own') {
    const cost = 600;
    if (!canAffordGold(hero, cost)) {
      toast?.('Not enough gold.');
      return { log: ['Insufficient gold.'] };
    }
    payGold(ctx, id, cost);
    // Optionally set a hero flag to remember the once-per Adventure ability trigger
    const s = loadTownState() || {};
    const heroFlags = { ...(s.heroFlags || {}) };
    heroFlags[id] = { ...(heroFlags[id] || {}), devilsOwnOwned: true };
    saveTownState({ ...s, heroFlags });
    toast?.("Purchased The Devil's Own.");
    return { log: ["Bought The Devil's Own."] };
  }

  if (serviceId === 'gh_dark_stone_poker_chip') {
    // price may be composite: { gold: 800, darkStone: 1 }
    const goldCost = Number((gamblingHallServices.find(svc => svc.id === serviceId)?.price?.gold) ?? 800);
    const dsCost = Number((gamblingHallServices.find(svc => svc.id === serviceId)?.price?.darkStone) ?? 1);
    const ds = Number(hero.darkStone || 0);
    if (!canAffordGold(hero, goldCost) || ds < dsCost) {
      toast?.('Not enough resources.');
      return { log: ['Insufficient gold/Dark Stone.'] };
    }
    payGold(ctx, id, goldCost);
    ctx.updateHero?.(id, (h) => ({ ...h, darkStone: Math.max(0, (h.darkStone || 0) - dsCost) }));

    // +1 Luck & “+50 on Gambling Gains” flag
    ctx.updateHero?.(id, (h) => ({
      ...h,
      effects: { ...(h.effects || {}), Luck: (h.effects?.Luck || 0) + 1 },
    }));
    const s = loadTownState() || {};
    const heroFlags = { ...(s.heroFlags || {}) };
    heroFlags[id] = { ...(heroFlags[id] || {}), dsPokerChip: true };
    saveTownState({ ...s, heroFlags });

    toast?.('Purchased Dark Stone Poker Chip (+1 Luck; +$50 on gambling gains).');
    return { log: ['Bought Dark Stone Poker Chip.'] };
  }

  return { log: [`[GamblingHall] Unknown service: ${serviceId}`] };
}

export async function performGamblingHallServiceObj(service, params = {}, ctx = {}) {
  return performGamblingHallService(service?.id, params, ctx);
}

export default { performGamblingHallService, performGamblingHallServiceObj };
