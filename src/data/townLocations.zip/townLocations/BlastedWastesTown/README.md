# BlastedWastesTown
Placeholder town data.
